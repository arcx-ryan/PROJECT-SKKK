const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
require('dotenv').config();

async function main() {
  const hash = await bcrypt.hash('admin123', 10);
  console.log('Generated hash:', hash);
  
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
  });
  
  await conn.execute('UPDATE users SET password = ? WHERE username = ?', [hash, 'admin']);
  const [rows] = await conn.execute('SELECT id, nama, username, password, role FROM users WHERE username = ?', ['admin']);
  console.log('Updated row:', rows[0]);
  
  // Verify
  const match = await bcrypt.compare('admin123', rows[0].password);
  console.log('Password match:', match);
  
  await conn.end();
}
main().catch(console.error);
